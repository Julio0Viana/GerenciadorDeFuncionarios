import datetime
import sqlite3

def conectar_db():
    return sqlite3.connect('empresa.db')

# verifica se a tabela de funcionários existe
def criar_tabela():
    conn = conectar_db()
    cursor = conn.cursor()
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS funcionarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome TEXT NOT NULL,
        cargo TEXT NOT NULL,
        salario REAL NOT NULL,
        data_de_admissao TEXT NOT NULL
    )
    ''')
    conn.commit()
    conn.close()

def adicionar_funcionario_db(nome, cargo, salario, data_de_admissao):
    conn = conectar_db()
    cursor = conn.cursor()
    # Converte o objeto datetime.date para a string ISO format (YYYY-MM-DD)
    data_str = data_de_admissao.isoformat()

    sql = "INSERT INTO funcionarios (nome, cargo, salario, data_de_admissao) VALUES (?, ?, ?, ?)"

    try:
        cursor.execute(sql, (nome, cargo, salario, data_str))
        conn.commit()
        print("Funcionário adicionado com sucesso ao banco de dados.")

    except Exception as e:
        print(f"Erro ao adicionar funcionário ao banco de dados: {e}")
    finally:
        cursor.close()
        conn.close()

def listar_funcionarios():
    conn = conectar_db()
    cursor = conn.cursor()

    sql = """
    SELECT id, nome, cargo, salario, data_de_admissao, CAST(JULIANDAY('now') - JULIANDAY(data_de_admissao) AS INTEGER) AS tempo_em_dias
    FROM funcionarios
    """
    cursor.execute(sql)
    funcionarios_db = cursor.fetchall()
    conn.close()

    if not funcionarios_db:
        print("Nenhum funcionário cadastrado.")
        return
    
    print("\nLista de Funcionários:")
    for (id_func, nome, cargo, salario, data_admissao_str, tempo_em_dias) in funcionarios_db:
        
        if tempo_em_dias < 30:
            tempo_formatado = f"{tempo_em_dias} dias"
        elif tempo_em_dias < 365:
            tempo_em_meses = round(tempo_em_dias / 30)
            tempo_formatado = f"{tempo_em_meses} meses ({tempo_em_dias} dias)"
        else:
            tempo_em_anos = round(tempo_em_dias / 365)
            tempo_formatado = f"{tempo_em_anos} anos ({tempo_em_dias} dias)"

        data_admissao = datetime.datetime.strptime(data_admissao_str, "%Y-%m-%d").strftime("%d/%m/%Y")

        print(f"ID: {id_func:<3} | Nome: {nome:<20} | Cargo: {cargo:<15} | Salário: R$ {salario:.2f} | Admissão: {data_admissao} | Tempo: {tempo_formatado}")

def vizualizar_media_salarial():
    conn = conectar_db()
    cursor = conn.cursor()

    cursor.execute("SELECT AVG(salario), COUNT(id) FROM funcionarios")
    resultado = cursor.fetchone()
    conn.close()

    if resultado is None or resultado[1] == 0:
        print("Nenhum funcionário cadastrado.")
        return

    media = resultado[0]
    print(f"A Média Salarial da empresa é: {media:.2f}")

def buscar_funcionario():
    conn = conectar_db()
    cursor = conn.cursor()
    nome_busca = input("Digite o nome do funcionário que deseja buscar (Nome completo): ")

    sql = """SELECT nome, cargo, salario, data_de_admissao, CAST(JULIANDAY('now') - JULIANDAY(data_de_admissao) AS INTEGER) AS tempo_em_dias FROM funcionarios WHERE nome LIKE ?"""
    cursor.execute(sql, (f'%{nome_busca}%',))
    funcionario = cursor.fetchone()
    conn.close()

    if funcionario:
        nome, cargo, salario, data_admissao_str, tempo_em_dias = funcionario
        
        if tempo_em_dias < 30:
            tempo_formatado = f"{tempo_em_dias} dias"
        elif tempo_em_dias < 365:
            tempo_em_meses = round(tempo_em_dias / 30)
            tempo_formatado = f"{tempo_em_meses} meses ({tempo_em_dias} dias)"
        else:
            tempo_em_anos = round(tempo_em_dias / 365)
            tempo_formatado = f"{tempo_em_anos} anos ({tempo_em_dias} dias)"

        data_admissao = datetime.datetime.strptime(data_admissao_str, "%Y-%m-%d").strftime("%d/%m/%Y")

        print(f"Funcionário encontrado: Nome: {nome}, Cargo: {cargo}, Salário: {salario}, Data de Admissão: {data_admissao}, Tempo de Empresa: {tempo_formatado}")
    else:
        print("Funcionário não encontrado.")

def excluir_funcionario():
    conn = conectar_db()
    cursor = conn.cursor()
    listar_funcionarios()
    while True:
        try:
            id_excluir = int(input("\nDigite o ID do funcionário que deseja EXCLUIR (0 para cancelar): "))
            if id_excluir == 0:
                print("Operação de exclusão cancelada.")
                conn.close()
                return
            break
        except ValueError:
            print("ID inválido. Por favor, digite um número inteiro.")
    # Verifica se o ID existe
    cursor.execute("SELECT nome FROM funcionarios WHERE id = ?", (id_excluir,))
    funcionario_nome = cursor.fetchone()
    
    if funcionario_nome:
        nome_func = funcionario_nome[0]
        #  Pede confirmação
        confirmacao = input(f"Tem certeza que deseja excluir o funcionário '{nome_func}' (ID: {id_excluir})? (s/n): ").lower()
        
        if confirmacao == 's':
            # Executa a exclusão
            sql = "DELETE FROM funcionarios WHERE id = ?"
            cursor.execute(sql, (id_excluir,))
            conn.commit()
            
            print(f"Funcionário '{nome_func}' excluído com sucesso.")
        else:
            print("Exclusão cancelada pelo usuário.")
    else:
        # Se a busca não encontrou, informa o usuário
        print("Funcionário não encontrado. O ID digitado não existe no banco de dados.")

    conn.close()

    

def menu():
    print("\n============ MENU ============")
    print("1. Adicionar Funcionário")
    print("2. Listar Funcionários")
    print("3. Buscar Funcionário")
    print("4. Visualizar média salarial dos funcionários")
    print("5. Excluir Funcionário")
    print("6. Sair")
    print("==============================")

    while True:
        try:
            return int(input("Escolha uma opção: "))
        except ValueError:
            print("Opção inválida. Digite um número.")

criar_tabela()

while True:
    cadastro = menu()
    if cadastro == 1:
        nome = input("Nome: ")
        cargo = input("Cargo: ")
        salario = float(input("Salário: ").replace(',', '.'))
        data_de_admissao = input("Data de Admissão (DD/MM/AAAA): ")
        data_de_admissao = datetime.datetime.strptime(data_de_admissao, "%d/%m/%Y").date()
        adicionar_funcionario_db(nome, cargo, salario, data_de_admissao)
    elif cadastro == 2:
        listar_funcionarios()
    elif cadastro == 3:
        buscar_funcionario()
    elif cadastro == 4:
        vizualizar_media_salarial()
    elif cadastro == 5:
        excluir_funcionario()
    elif cadastro == 6:
        print("Saindo...")
        break
    else:
        print("Opção inválida. Tente novamente.")

